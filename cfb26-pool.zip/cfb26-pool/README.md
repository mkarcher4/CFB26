# CFB26 Pool

A season-long college football scoring pool tracker for 10 coaches, 14 teams each. Static site + a scheduled GitHub Action that keeps schedule/score data in sync with ESPN automatically -- same pattern as the fantasy football league trackers (Python fetch script + GitHub Actions + GitHub Pages).

## How it works

- **`index.html`** -- the whole app (Standings, Rosters, Schedule, Rules). Loads `data/schedule.json` and `data/manual.json` on page load, no build step.
- **`data/draft.json`** -- who drafted which 14 teams. Source of truth for `scripts/fetch_espn.py`; `index.html` also has this hardcoded at the top (`const DRAFT = {...}`) so if you ever change a team, **update both places**.
- **`data/schedule.json`** -- every drafted team's opponent/score/status per week. Written automatically by `scripts/fetch_espn.py`. Don't hand-edit this file directly in the repo under normal use -- see "Manual corrections" below.
- **`data/manual.json`** -- the Commissioner-entered bonus fields per team (bowl eligibility, Heisman, conference championships, CFP rounds, HC firings). This is the one file a human edits.
- **`.github/workflows/sync.yml`** -- runs `scripts/fetch_espn.py` every hour and commits `data/schedule.json` if anything changed.

## One-time setup

1. Create a new **public** GitHub repo and push everything in this folder to it.
2. In the repo, go to **Settings → Pages** → under "Build and deployment", set Source to "Deploy from a branch", branch `main`, folder `/ (root)`. Save. GitHub gives you a URL like `https://<username>.github.io/<repo>/` -- that's the link to share with your 10 coaches.
3. Go to **Settings → Actions → General** → under "Workflow permissions", select **"Read and write permissions"**. This is required so the scheduled sync can commit `data/schedule.json` back to the repo.
4. That's it -- no API keys or secrets needed. ESPN's scoreboard endpoint used here is public.

The sync runs automatically every hour (see the `cron` line in `.github/workflows/sync.yml` if you want it more/less frequent). You can also trigger it manually any time from the **Actions** tab → "Sync ESPN Data" → "Run workflow".

## Commissioner Mode

The Rosters and Schedule tabs are locked for editing until you click **Commissioner Login** and enter the PIN (set in `index.html`, search for `COMMISSIONER_PIN` -- change it to whatever you like before you publish the repo).

**Important -- this is a static site, so edits don't save themselves.** When you toggle a bonus field or hand-correct a schedule entry:

1. The change applies immediately in your browser, but nowhere else yet.
2. A "Download manual.json" (Rosters tab) or "Download schedule.json" (Schedule tab) button appears -- click it to download the updated file.
3. Replace the file of the same name in `data/` in your repo (drag-and-drop upload through GitHub's web UI works fine, or `git add && git commit && git push` if you're comfortable with git) and commit.
4. Once committed, everyone loading the page sees the change -- GitHub Pages serves whatever's currently in `main`.

This is a deliberate trade-off for a zero-infrastructure, zero-cost setup: no server, no database, nothing that can go down. The cost is that manual edits are a "download → commit" step rather than instant, same as the ESPN data used to require it before this was automated.

## Local testing

Don't open `index.html` directly by double-clicking it -- browsers block `fetch()` of local files under `file://`, so `data/*.json` won't load. Instead, from the repo root:

```bash
python3 -m http.server 8000
```

then open `http://localhost:8000` in a browser.

To test the fetch script locally:

```bash
pip install requests
python3 scripts/fetch_espn.py
```

This is safe to run any time -- it merges into whatever's already in `data/schedule.json` rather than starting over, and only overwrites a week's data if ESPN's response for that week parses cleanly.

## Team-name matching

`scripts/fetch_espn.py` has a `NAME_ALIASES` table that maps ESPN's shorthand team names (e.g. "Ohio St", "W Michigan") to the names in `data/draft.json`. If a game shows up as a "non-pool opponent" in the Schedule tab for a team you know is actually in the pool, that's almost always a missing alias -- add the ESPN-side spelling to `NAME_ALIASES` in `scripts/fetch_espn.py`. The same table exists in `index.html` (`NAME_ALIASES` there too) purely so manual schedule edits made in Commissioner Mode match consistently -- keep the two in sync if you add an entry.

## Money Owed rules (for reference)

- $75 buy-in per coach ($750 pool total)
- +$10 to the weekly point leader, Week 1 through Week 15 (Week 0 doesn't count; ties split the $10 evenly)
- +$100 to whoever leads the regular-season standings after Week 15
- +$20 to whoever scores the most postseason points
- Final overall standings pay $250 / $150 / $100 for 1st / 2nd / 3rd (ties split the combined prize money for the tied places)

These are implemented in `index.html` under `computeMoneyOwed()` if you ever need to change the numbers.
